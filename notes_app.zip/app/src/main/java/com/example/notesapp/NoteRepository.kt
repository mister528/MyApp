package com.example.notesapp

import kotlinx.coroutines.flow.Flow

class NoteRepository(private val noteDao: NoteDao) {
    
    fun getAllNotesByDate(): Flow<List<Note>> = noteDao.getAllNotesByDate()
    
    fun getAllNotesByTitle(): Flow<List<Note>> = noteDao.getAllNotesByTitle()
    
    fun searchNotes(query: String): Flow<List<Note>> = noteDao.searchNotes(query)
    
    suspend fun getNoteById(id: Long): Note? = noteDao.getNoteById(id)
    
    suspend fun insertNote(note: Note): Long = noteDao.insertNote(note)
    
    suspend fun updateNote(note: Note) = noteDao.updateNote(note)
    
    suspend fun deleteNote(note: Note) = noteDao.deleteNote(note)
}

