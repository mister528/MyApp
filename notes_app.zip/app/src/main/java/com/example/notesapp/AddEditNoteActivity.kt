package com.example.notesapp

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.notesapp.databinding.ActivityAddEditNoteBinding
import kotlinx.coroutines.launch

class AddEditNoteActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityAddEditNoteBinding
    private val viewModel: AddEditNoteViewModel by viewModels {
        AddEditNoteViewModelFactory((application as NotesApplication).repository)
    }
    
    private var noteId: Long = -1
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddEditNoteBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        noteId = intent.getLongExtra("note_id", -1)
        
        setupToolbar()
        setupClickListeners()
        
        if (noteId != -1L) {
            loadNote()
            binding.deleteButton.visibility = View.VISIBLE
            binding.toolbar.title = getString(R.string.edit_note)
        }
    }
    
    private fun setupToolbar() {
        binding.toolbar.setNavigationOnClickListener {
            finish()
        }
    }
    
    private fun setupClickListeners() {
        binding.saveButton.setOnClickListener {
            saveNote()
        }
        
        binding.deleteButton.setOnClickListener {
            showDeleteConfirmationDialog()
        }
    }
    
    private fun loadNote() {
        lifecycleScope.launch {
            viewModel.getNoteById(noteId)?.let { note ->
                binding.titleEditText.setText(note.title)
                binding.contentEditText.setText(note.content)
            }
        }
    }
    
    private fun saveNote() {
        val title = binding.titleEditText.text.toString().trim()
        val content = binding.contentEditText.text.toString().trim()
        
        if (title.isEmpty()) {
            binding.titleInputLayout.error = "العنوان مطلوب"
            return
        }
        
        if (content.isEmpty()) {
            binding.contentInputLayout.error = "المحتوى مطلوب"
            return
        }
        
        binding.titleInputLayout.error = null
        binding.contentInputLayout.error = null
        
        lifecycleScope.launch {
            if (noteId == -1L) {
                viewModel.insertNote(title, content)
            } else {
                viewModel.updateNote(noteId, title, content)
            }
            
            Toast.makeText(this@AddEditNoteActivity, "تم حفظ المذكرة", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
    
    private fun showDeleteConfirmationDialog() {
        AlertDialog.Builder(this)
            .setTitle("حذف المذكرة")
            .setMessage("هل أنت متأكد من حذف هذه المذكرة؟")
            .setPositiveButton("حذف") { _, _ ->
                deleteNote()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }
    
    private fun deleteNote() {
        lifecycleScope.launch {
            viewModel.deleteNote(noteId)
            Toast.makeText(this@AddEditNoteActivity, "تم حذف المذكرة", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}

