package com.example.notesapp

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import java.util.*

class AddEditNoteViewModel(private val repository: NoteRepository) : ViewModel() {
    
    suspend fun getNoteById(id: Long): Note? {
        return repository.getNoteById(id)
    }
    
    suspend fun insertNote(title: String, content: String): Long {
        val currentDate = Date()
        val note = Note(
            title = title,
            content = content,
            dateCreated = currentDate,
            dateModified = currentDate
        )
        return repository.insertNote(note)
    }
    
    suspend fun updateNote(id: Long, title: String, content: String) {
        val existingNote = repository.getNoteById(id)
        existingNote?.let { note ->
            val updatedNote = note.copy(
                title = title,
                content = content,
                dateModified = Date()
            )
            repository.updateNote(updatedNote)
        }
    }
    
    suspend fun deleteNote(id: Long) {
        val note = repository.getNoteById(id)
        note?.let {
            repository.deleteNote(it)
        }
    }
}

class AddEditNoteViewModelFactory(private val repository: NoteRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(AddEditNoteViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return AddEditNoteViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

